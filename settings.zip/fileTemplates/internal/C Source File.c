#parse("C File Header.h")
#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"
#end
# include <iostream>
# include <string.h>
# include "algorithm"
# include "vector"
# include "queue"
# include "stack"
# include "unordered_set"
# include "unordered_map"
#ifdef CLIONENV
int debug =1;
#endif
#ifndef CLIONENV
int debug = 0;
#endif
using namespace std;
int main114514() {
    Solution s;
    vector<int>  input = {8, -8};
    
    return 0;
}
